<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Skirt Information</title>
       <link rel="stylesheet" href="uniforms.css">
       <style>
    body{
            background-color: black;
            background-image: url("assets\\img\\skirt1.jpg");
     
            background-size: 40%; /* Make sure the image covers the entire area */
            background-position:center; /* Center the background image */
            background-repeat: repeat;
            margin: top 0;
        }
        </style>
  </head>
  <body>
    <h1>Skirt Information</h1>

    <div class="info-section">
      <h2>Select School:</h2>
      <select id="school" onchange="updateColour()">
        <option value="Masibambane High School">Masibambane High School</option>
        <option value="Wallacedene High School">Wallacedene High School</option>
        <option value="Hector Peterson">Hector Peterson</option>
        <option value="Nqalweni JSS">Nqalweni JSS</option>
        <option value="Victory Christian School">
          Victory Christian School
        </option>
        <option value="Idutywa School of Excellence">
          Idutywa School of Excellence
        </option>
        <option value="Not in list">Not in list</option>
      </select>
    </div>

    <div class="info-section">
      <h2>Select Size:</h2>
      <select id="size">
        <option value="24">24</option>
        <option value="26">26</option>
        <option value="28">28</option>
        <option value="30">30</option>
        <option value="32">32</option>
        <option value="34">34</option>
        <option value="36">36</option>
        <option value="38">38</option>
        <option value="40">40</option>
        <option value="42">42</option>
        <option value="44">44</option>
      </select>
    </div>

    <div class="info-section">
      <h2>Select Type of Skirt:</h2>
      <select id="type_skirt" onchange="updatePriceAndImage()">
        <option value="plitted">Plitted</option>
        <option value="6 panel">6 Panel</option>
      </select>
    </div>

    <div class="info-section">
      <h2>Select Colour:</h2>
      <select id="colour">
        <option value="Checked maroon">Checked maroon</option>

        <option value="Navy">Navy</option>
        <option value="Black">Black</option>
        <option value="Grey">Grey</option>
        <option value="Blue">Blue</option>
        <option value="Royal blue">Royal blue</option>
        <option value="Red">Red</option>
      </select>
    </div>

    <div class="info-section">
      <button onclick="addToCart()">Add to Cart</button>
    </div>

    <div class="info-section">
      <div class="uniform-item">
        <div>
          <p class="price" id="price">R100.00</p>
        </div>
      </div>

      <div>
        <a href="uniform.php">Back</a>
      </div>
      <div id="cart">
        <a href="latest_cart.php">Go to Cart</a>
      </div>
    </div>

    <script>
      function updatePriceAndImage() {
        const typeSkirt = document.getElementById("type_skirt").value;
        let price;
        let imageSrc;

        if (typeSkirt === "plitted") {
          price = 250;
          imageSrc = "plited skirt.jpg"; // Add the correct path to the plitted skirt image
        } else if (typeSkirt === "6 panel") {
          price = 230;
          imageSrc = "6 panel skirt.jpg"; // Add the correct path to the 6 panel skirt image
        }

        document.getElementById("price").innerText = "R" + price + ".00";
        document.getElementById("skirt-image").src = imageSrc;
      }
      function updateColour() {
        const school = document.getElementById("school").value;
        const colourSelect = document.getElementById("colour");

        if (school === "Wallacedene High School") {
          colourSelect.value = "Black";
        } else if (school === "Masibambane High School") {
          colourSelect.value = "Blue";
        } else if (school === "Hector Peterson") {
          colourSelect.value = "Navy";
        } else if (school === "Nqalweni JSS") {
          colourSelect.value = "Grey";
        } else if (school === "Victory Christian School") {
          colourSelect.value = "Royal blue";
        } else if (school === "Idutywa School of Excellence") {
          colourSelect.value = "Checked maroon";
        } else if (school === "Not in list") {
          colourSelect.value = "Red";
        }
      }
      function addToCart() {
        const school = document.getElementById("school").value;
        const size = document.getElementById("size").value;
        const typeSkirt = document.getElementById("type_skirt").value;
        const colour = document.getElementById("colour").value;
        const price = typeSkirt === "plitted" ? 250 : 230;

        const cartItem = {
          school,
          size,
          typeSkirt,
          colour,
          price,
          quantity: 1,
        };

        let cart = JSON.parse(localStorage.getItem("cart")) || [];
        cart.push(cartItem);
        localStorage.setItem("cart", JSON.stringify(cart));

        alert(
          "Item added to cart: " +
            school +
            ", " +
            size +
            ", " +
            typeSkirt +
            ", " +
            colour +
            ", R" +
            price
        );
      }
      window.onload = function () {
        document.getElementById("school").value = "Nqalweni JSS";
        document.getElementById("colour").value = "Grey";
      };
    </script>
  </body>
</html>
