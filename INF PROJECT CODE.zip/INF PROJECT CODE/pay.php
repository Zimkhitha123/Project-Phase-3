<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Payment Page</title>
    <link
      href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap"
      rel="stylesheet"
    />
    <style>
      body {
        font-family: "Roboto", sans-serif;
        background-color: #f7f7f7;
        margin: 0;
        padding: 0;
      }
      .container {
        width: 40%;
        margin: 50px auto;
        background-color: #fff;
        padding: 30px;
        border-radius: 10px;
        box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
      }
      h2 {
        text-align: center;
        margin-bottom: 20px;
      }
      .form-group {
        margin-bottom: 15px;
      }
      .form-group label {
        display: block;
        margin-bottom: 5px;
        font-weight: bold;
      }
      .form-group input {
        width: calc(100% - 22px);
        padding: 10px;
        font-size: 16px;
        border: 1px solid #ccc;
        border-radius: 5px;
      }
      .form-group .input-small {
        width: 48%;
      }
      .form-group .inline-group {
        display: flex;
        justify-content: space-between;
      }
      .form-group button {
        width: 100%;
        padding: 10px;
        background-color: #c72185;
        color: white;
        font-size: 18px;
        border: none;
        cursor: pointer;
        border-radius: 5px;
        margin-top: 20px;
      }
      .form-group button:hover {
        background-color: #4b042f;
      }
    </style>
  </head>
  <body>
    <div class="container">
      <h2>Payment Information</h2>
      <form id="process-payment">
        <div class="form-group">
          <label for="cardName">Cardholder Name</label>
          <input
            type="text"
            id="cardName"
            name="cardName"
            placeholder="cardholder name"
            required
          />
        </div>
        <div class="form-group">
          <label for="cardNumber">Card Number</label>
          <input
            type="number"
            id="cardNumber"
            name="cardNumber"
            placeholder="1234 5678 9012 3456"
            required
          />
        </div>
        <div class="form-group inline-group">
          <div class="input-small">
            <label for="expDate">Expiration Date</label>
            <input
              type="date"
              id="expDate"
              name="expDate"
              placeholder="MM/YY"
              required
            />
          </div>
          <div class="input-small">
            <label for="cvv">CVV</label>
            <input type="text" id="cvv" name="cvv" placeholder="123" required />
          </div>
        </div>
        <div class="form-group">
        <button onclick="checkout()">Checkout</button>
        </div>
      </form>
    </div>
  </body>
  <script>
     function checkout() {
            alert('Checkout successful, happy shopping!');
            window.location.href = 'index.php';
        }
  </script>
</html>
