<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Golfer Information</title>
    <link rel="stylesheet" href="uniforms.css" />
    <style>
    body{
            background-color: black;
            background-image: url("assets\\img\\Golfer3.jpg");
     
            background-size: 100%; /* Make sure the image covers the entire area */
            background-position:center; /* Center the background image */
            background-repeat: repeat;
            margin: top 0;
        }
        </style>
  </head>
  <body>
    <h1>Golfer Information</h1>

    <div class="info-section">
      <h2>Select School:</h2>
      <select id="school" onchange="updateColours()">
        <option value="ET Thabane primary school">
          ET Thabane primary school
        </option>
        <option value="Wonderland JSS">Wonderland JSS</option>
        <option value="Wallacedene High School">Wallacedene High School</option>
        <option value="Hector Peterson">Hector Peterson</option>
        <option value="Nqalweni JSS">Nqalweni JSS</option>
        <option value="Not in list">Not in list</option>
      </select>
    </div>

    <div class="info-section">
      <h2>Select Size:</h2>
      <select id="size">
        <option value="20">20</option>
        <option value="22">22</option>
        <option value="24">24</option>
        <option value="26">26</option>
        <option value="28">28</option>
        <option value="30">30</option>
        <option value="Small">Small</option>
        <option value="Medium">Medium</option>
        <option value="large">large</option>
        <option value="Extra large">Extra large</option>
      </select>
    </div>

    <div class="info-section">
      <h2>Select Colour:</h2>
      <select id="colour" onchange="updatePriceAndImage()">
        <option value="Navy blue">Navy blue</option>
        <option value="Black">Black</option>
        <option value="Gold">Gold</option>
        <option value="White">White</option>
        <option value="Blue">Blue</option>
        <option value="Wonderland JSS golfer with badge">
          Wonderland JSS golfer with badge
        </option>
      </select>
    </div>

    <div class="info-section">
      <button onclick="addToCart()">Add to Cart</button>
    </div>

    <div class="info-section">
      <div class="uniform-item">
        <div>
         
          <p class="price" id="price">R200.00</p>
        </div>
      </div>
      <div>
        <a href="uniform.php">Back</a>
      </div>
      <div id="cart">
        <a href="latest_cart.php">Go to Cart</a>
      </div>
    </div>

    <script>
      

      function addToCart() {
        const school = document.getElementById("school").value;
        const colour = document.getElementById("colour").value;
        const size = document.getElementById("size").value;
        const price = document
          .getElementById("price")
          .innerText.replace("R", "")
          .replace(".00", "");

        const cartItem = { school, size, colour, price, quantity: 1 };

        let cart = JSON.parse(localStorage.getItem("cart")) || [];
        cart.push(cartItem);
        localStorage.setItem("cart", JSON.stringify(cart));

        alert("Item added to cart: " + school + ", " + size + ", " + colour);
      }

      window.onload = function () {
        document.getElementById("school").value = "Nqalweni JSS";
        document.getElementById("colour").value = "Blue";
        updatePriceAndImage(); // Sync price and image on load
      };
    </script>
  </body>
</html>
