<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Socks Information</title>
        <link rel="stylesheet" href="uniforms.css">
        <link rel="stylesheet" href="uniforms.css">
       <style>
    body{
            background-color: black;
            background-image: url("assets\\img\\nguyena.jpg");
     
            background-size: 65%; /* Make sure the image covers the entire area */
            background-position:center; /* Center the background image */
            background-repeat: repeat;
            margin: top 0;
        }
        </style>
  </head>
  <body>
    <h1>Socks Information</h1>

    <div class="info-section">
      <h2>Select School:</h2>
      <select id="school" onchange="updateColour()">
        <option value="Masibambane High School">Masibambane High School</option>
        <option value="Wallacedene High School">Wallacedene High School</option>
        <option value="Hector Peterson">Hector Peterson</option>
        <option value="Nqalweni JSS">Nqalweni JSS</option>
        <option value="Not in list">Not in list</option>
      </select>
    </div>

    <div class="info-section">
      <h2>Select Sock Type:</h2>
      <select id="sockType" onchange="updatePrice()">
        <option value="short">Short Socks (R45)</option>
        <option value="long">Long Socks (R55)</option>
      </select>
    </div>

    <div id="sizeSelection" class="info-section">
      <h2>Select Size:</h2>
      <select id="size">
        <option value="Small">Small</option>
        <option value="Medium">Medium</option>
        <option value="Large">Large</option>
      </select>
    </div>

    <div class="info-section">
      <h2>Select Colour:</h2>
      <select id="colour">
        <option value="Navy">Navy</option>
        <option value="Black and White">Black and White</option>
        <option value="Black and powder blue">Black and powder blue</option>
        <option value="Black and red">Black and red</option>
        <option value="Black and Gold">Black and Gold</option>
        <option value="Red and White">Red and White</option>
        <option value="Green and Gold">Green and Gold</option>
        <option value="Navy and white">Navy and white</option>
        <option value="Navy and red">Navy and red</option>
        <option value="Maroon and baige">Maroon and baige</option>
        <option value="Green and white">Green and white</option>
        <option value="Maroon">Maroon</option>
        <option value="Powder blue and white">Powder blue and white</option>
      </select>
    </div>

    <div class="info-section">
      <button onclick="addToCart()">Add to Cart</button>
    </div>

    <div class="info-section"></div>
      <div class="uniform-item">
      </div>
    </div>

    <div>
      <a href="uniform.php">Back</a>
    </div>
    <div id="cart">
      <a href="latest_cart.php">Go to Cart</a>
    </div>

    <script>
      function updatePrice() {
        const sockType = document.getElementById("sockType").value;
        const priceElement = document.querySelector(".price");

        if (sockType === "short") {
          priceElement.textContent = "R45.00";
        } else if (sockType === "long") {
          priceElement.textContent = "R55.00";
        }
      }

      function addToCart() {
        const school = document.getElementById("school").value;
        const sockType = document.getElementById("sockType").value;
        const size = document.getElementById("size").value;
        const colour = document.getElementById("colour").value;
        const price = sockType === "short" ? 45 : 55;

        const cartItem = { school, sockType, size, colour, price, quantity: 1 };

        let cart = JSON.parse(localStorage.getItem("cart")) || [];
        cart.push(cartItem);
        localStorage.setItem("cart", JSON.stringify(cart));

        alert(
          "Item added to cart: " +
            school +
            ", " +
            sockType +
            ", " +
            size +
            ", " +
            colour
        );
      }

      function updateColour() {
        const school = document.getElementById("school").value;
        const colourSelect = document.getElementById("colour");

        if (school === "Masibambane High School") {
          colourSelect.value = "Navy";
        } else if (school === "Wallacedene High School") {
          colourSelect.value = "Red and White";
        } else if (school === "Hector Peterson") {
          colourSelect.value = "Powder blue and white";
        } else if (school === "Nqalweni JSS") {
          colourSelect.value = "Green and Gold";
        }
      }

      window.onload = function () {
        document.getElementById("school").value = "Nqalweni JSS";
        document.getElementById("colour").value = "Green and Gold";
      };
    </script>
  </body>
</html>
