<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Trousers Information</title>
    <link rel="stylesheet" href="uniforms.css" />
    <style>
    body{
            background-color: black;
            background-image: url("assets\\img\\trouser3.jpg");
     
            background-size: 40%; /* Make sure the image covers the entire area */
            background-position:cover; /* Center the background image */
            background-repeat: repeat;
            margin: top 0;
        }
        </style>
  </head>
  <body>
    <h1>Trousers Information</h1>

    <div class="info-section">
      <h2>Select Size:</h2>
      <select id="size">
        <option value="3-4">3-4</option>
        <option value="5-6">5-6</option>
        <option value="7-8">7-8</option>
        <option value="9-10">9-10</option>
        <option value="11-12">11-12</option>
        <option value="13-14">13-14</option>
        <option value="15-16">15-16</option>
        <option value="Small">Small</option>
        <option value="Medium">Medium</option>
        <option value="Large">Large</option>
        <option value="Extra Large">Extra Large</option>
      </select>
    </div>
    <div class="info-section">
      <h2>Select Colour:</h2>
      <select id="colour">
        <option value="Black">Black</option>
      </select>
    </div>

    <div class="info-section">
      <button onclick="addToCart()">Add to Cart</button>
    </div>

    <div class="info-section">
      <div class="uniform-item">
        <div></div>
        
        <p class="price">R200.00</p>
      </div>
    </div>

    <div>
      <a href="uniform.php">Back</a>
    </div>
    <div id="cart">
      <a href="latest_cart.php">Go to Cart</a>
    </div>

    <script>
      function addToCart() {
        const colour = document.getElementById("colour").value;
        const size = document.getElementById("size").value;
        const price = 200;

        const cartItem = { size, colour, price, quantity: 1 };

        let cart = JSON.parse(localStorage.getItem("cart")) || [];
        cart.push(cartItem);
        localStorage.setItem("cart", JSON.stringify(cart));

        alert("Item added to cart: " + size + ", " + colour);
      }
    </script>
  </body>
</html>
