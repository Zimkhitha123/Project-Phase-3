<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        .profile {
            border: 1px solid #ccc;
            padding: 15px;
            border-radius: 5px;
            max-width: 400px;
            margin: auto;
        }
        h2 {
            color: #333;
        }
        .orders {
            margin-top: 20px;
        }
        .order {
            padding: 5px;
            border: 1px solid #ddd;
            margin-bottom: 5px;
            border-radius: 4px;
        }
    </style>
</head>
<body>
    <div class="profile">
        <h2>User Profile</h2>
        <div id="userInfo"></div>
        <div class="orders" id="userOrders"></div>
    </div>

    <script>
        // Replace with the desired user ID
        const userId = 1; 

        async function fetchUserProfile() {
            try {
                const response = await fetch('data.json');
                const data = await response.json();

                // Find the user by ID
                const user = data.users.find(u => u.id === userId);
                if (!user) throw new Error('User not found');

                displayUserInfo(user);
            } catch (error) {
                document.getElementById('userInfo').innerHTML = `<p>${error.message}</p>`;
            }
        }

        function displayUserInfo(user) {
            const userInfo = `
                <h3>${user.username}</h3>
                <p>Email: ${user.email}</p>
            `;
            document.getElementById('userInfo').innerHTML = userInfo;

            const ordersList = user.orders.map(order => `
                <div class="order">
                    <strong>Order ID:</strong> ${order.id}<br>
                    <strong>Product:</strong> ${order.product_name}
                </div>
            `).join('');

            document.getElementById('userOrders').innerHTML = `
                <h4>Orders:</h4>
                ${ordersList.length ? ordersList : '<p>No orders found.</p>'}
            `;
        }

        fetchUserProfile();
    </script>
</body>
</html>
