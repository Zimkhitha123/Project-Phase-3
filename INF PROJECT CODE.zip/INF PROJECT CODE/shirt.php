<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Shirt Information</title>
    <link rel="stylesheet" href="uniforms.css" />
    <style>
        body{
            background-color: black;
            background-image: url("assets\\img\\R (1).jpg");
     
            background-size: 100%; /* Make sure the image covers the entire area */
            background-position:center; /* Center the background image */
            background-repeat: repeat;
            margin: top 0;
        }
    </style>
  </head>
  <body>
    <div class="container">
      <h1>Shirt Information</h1>

      <div class="info-section">
        <h2>Select School:</h2>
        <select id="school" onchange="updateColour()">
          <option value="Masibambane High School">
            Masibambane High School
          </option>
          <option value="Hector Peterson">Hector Peterson</option>
          <option value="Nqalweni JSS">Nqalweni JSS</option>
          <option value="Not in list">Not in list</option>
        </select>
      </div>

      <div class="info-section">
        <h2>Select Size:</h2>
        <select id="size">
          <option value="20">20</option>
          <option value="22">22</option>
          <option value="24">24</option>
          <option value="26">26</option>
          <option value="28">28</option>
          <option value="30">30</option>
          <option value="Small">Small</option>
          <option value="Medium">Medium</option>
          <option value="Large">Large</option>
          <option value="Extra Large">Extra Large</option>
        </select>
      </div>

      <div class="info-section">
        <h2>Select Colour:</h2>
        <select id="colour" onchange="updatePriceAndImage()">
          <option value="Blue">Blue</option>
          <option value="Gold">Gold</option>
          <option value="Plain white">Plain white</option>
          <option value="Nqalweni JSS shirt with badge">
            Nqalweni JSS shirt with badge
          </option>
        </select>
      </div>

      <div class="info-section">
        <button onclick="addToCart()">Add to Cart</button>
      </div>

      <div class="uniform-item">
        <p class="price" id="price">R150.00</p>
      </div>

      <div id="cart">
        <a href="uniform.html">Back</a>
        <a href="latest_cart.php">Go to Cart</a>
      </div>
    </div>

    <script>
     

       
      
      function addToCart() {
        const school = document.getElementById("school").value;
        const size = document.getElementById("size").value;
        const colourShirt = document.getElementById("colour").value;

        const price =
          colourShirt === "Nqalweni JSS shirt with badge"
            ? 200
            : colourShirt === "Blue"
            ? 160
            : colourShirt === "Gold"
            ? 150
            : 120;

        const cartItem = {
          school,
          size,
          colourShirt,
          price,
          quantity: 1,
        };

        let cart = JSON.parse(localStorage.getItem("cart")) || [];
        cart.push(cartItem);
        localStorage.setItem("cart", JSON.stringify(cart));

        alert(
          "Item added to cart: " +
            school +
            ", " +
            size +
            ", " +
            colourShirt +
            ", R" +
            price
        );
      }

      window.onload = function () {
        document.getElementById("school").value = "Nqalweni JSS";
        document.getElementById("colour").value =
          "Nqalweni JSS shirt with badge";
        updatePriceAndImage();
      };
    </script>
  </body>
</html>
