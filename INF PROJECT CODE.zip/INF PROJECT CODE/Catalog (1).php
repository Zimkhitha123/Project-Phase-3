<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Uniform Catalog</title>
    <style>
body {
  font-family: Arial, sans-serif;
  margin: 0;
  padding: 0;
  background-image: url("machine.jpg");
  background-repeat: no-repeat;
  background-size: 120%; /* Zoom out effect */
  background-position: center;
}

header {
  text-align: center;
  padding-top: 100px; /* Adjust padding to create space for the fixed h1 */
}

h1 {
  color: white;
  font-size: 3rem; /* Increased font size */
  background-color: rgba(0, 0, 0, 0.7); /* Semi-transparent background */
  padding: 20px; /* Adds padding around the text */
  border-radius: 0; /* Removes rounding so it covers the full width */
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2); /* Adds shadow effect */
  margin: 0;
  width: 100%; /* Ensures the background covers the full screen width */
  position: fixed; /* Fixes the h1 at the top of the screen */
  top: 0; /* Places the h1 at the top of the page */
  left: 0; /* Aligns the element to the left edge */
  z-index: 1000; /* Ensures it stays on top of other elements */
}

main {
  display: flex; /* Use flexbox for horizontal layout */
  flex-direction: row;
  justify-content: space-around; /* Distribute space evenly */
  padding: 20px;
  margin-top: 120px; /* Adds space to compensate for the fixed h1 */
}

.catalog-section {
  background-color: rgba(173, 216, 230, 0.5); /* Semi-transparent background */
  color: solid white;
  border: 1px solid #ddd;
  border-radius: 5px;
  padding: 20px;
  width: 45%; /* Each section takes up 45% of the width */
}

.uniform-container {
  display: flex;
  flex-wrap: wrap; /* Allow wrapping for uniform cards */
  justify-content: space-between; /* Distribute cards evenly */
  background-color: rgba(0, 0, 0, 0.7); /* Semi-transparent background */
}

.uniform-card {
  flex: 1 1 calc(45% - 20px); /* Responsive card size */
  margin: 10px; /* Space between cards */
  border: 1px solid #ddd;
  border-radius: 5px;
  padding: 10px;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
}

.uniform-card img {
  max-width: 100%; /* Make image responsive */
  height: auto; /* Maintain aspect ratio */
}

.price {
  font-weight: bold;
  color: #ddd;
}

    </style>
  </head>
  <body>
    <header>
      <h1>Uniform Catalog</h1>
    </header>
    <main>
      <section class="catalog-section" id="summer">
        <h2>Summer Uniforms</h2>
        <div class="uniform-container">
          <div class="uniform-card">
            <img src="assets\\img\\shirt2.jpg" alt="Short-sleeve Shirts" />
            <h3>Short-sleeve Shirts</h3>
            <p class="price">R99.99</p>
          </div>
          <div class="uniform-card">
            <img src="assets\\img\\pullOver.jpg" alt="pull-over" />
            <h3>pull-over</h3>
            <p class="price">R189.99</p>
          </div>
          <div class="uniform-card">
            <img src="assets\\img\\tunic (2).jpg" alt="tunics" />
            <h3>Girls tunics</h3>
            <p class="price">R229.99</p>
          </div>
        </div>
      </section>

      <section class="catalog-section" id="winter">
        <h2>Winter Uniforms</h2>
        <div class="uniform-container">
          <div class="uniform-card">
            <img src="assets\\img\\jezi.jpg" alt="Jersey" />
            <h3>Jersey</h3>
            <p class="price">R199.99</p>
          </div>
          <div class="uniform-card">
            <img src="assets\\img\\tights.jpg" alt="tights" />
            <h3>Girls winter tights</h3>
            <p class="price">R59.99</p>
          </div>
          <div class="uniform-card">
            <img src="assets\\img\\mnqwazi.jpg" alt="Beanie" />
            <h3>Beanie</h3>
            <p class="price">R69.99</p>
          </div>
          <div class="uniform-card">
            <img src="assets\\img\\blazarcat.jpg" alt="Blazer" />
            <h3>Blazer</h3>
            <p class="price"><Ri:d></Ri:d>R74.99</p>
          </div>
          <div class="uniform-card">
            <img src="assets\\img\\matric-jercey.jpg" alt="Matric Jecket" />
            <h3>Matric Jecket</h3>
            <p class="price"><Ri:d></Ri:d>From R750</p>
          </div>
          <div class="uniform-card">
            <img src="assets\\img\\raincoat.jpg" alt="Rain Coat" />
            <h3>Rain Coat</h3>
            <p class="price"><Ri:d></Ri:d>R150.99</p>
          </div>
        </div>
      </section>
    </main>
  </body>
</html>
