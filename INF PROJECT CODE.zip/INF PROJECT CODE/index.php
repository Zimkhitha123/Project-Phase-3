<?php
session_start(); // Start the session

// Check if user is logged in
$isLoggedIn = isset($_SESSION["CUST_ID"]); // Determine if user is logged in
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Welcome to Khanya Store</title>
    <link rel="stylesheet" href="index.css" />
    <script src="script.js" defer></script>
</head>
<body>
    <nav>
        <ul id="menu-button">
            <li>
                <button class="menu2-button">Home</button>
            </li>
            <li class="menu test-menu">
                <button class="menu2-button">Menu</button>
                <div class="menu-content">
                    <a href="uniform.php">Uniform</a>
                    <a href="Catalog (1).php">Catalog</a>
                    <a href="return.php">Returns</a>
                    <a href="trackorders.php">Track Order</a>
                    <a href="latest_cart.php">Cart</a>
                </div>
            </li>
            <li>
                <button class="menu2-button" onclick="window.location.href='about.html'">
                    About
                </button>
            </li>
            <li>
                <button class="menu2-button" onclick="window.location.href='services.php'">
                    Services
                </button>
            </li>
            <li>
                <button class="menu2-button" onclick="window.location.href='Reviews.html'">
                    Reviews
                </button>
            </li>
            <li>
                <button class="menu2-button" onclick="window.location.href='Contact.html'">
                    Contact Us
                </button>
            </li>
            <li>
                <?php if ($isLoggedIn): ?>
                    <!-- Display Profile button if user is logged in -->
                    <button class="menu2-button" onclick="window.location.href='profile.php'">
                        Profile
                    </button>
                    <!-- Display Logout button -->
                    <button class="menu2-button" onclick="window.location.href='includes/logout.inc.php'">
                        Logout
                    </button>
                <?php else: ?>
                    <!-- Display Sign In button if user is not logged in -->
                    <button class="menu2-button" onclick="window.location.href='payment.php'">
                        Sign In
                    </button>
                <?php endif; ?>
            </li>
        </ul>
    </nav>
    <img src="../assets/img/Home.png" alt="Uniform 2" />
</body>
</html>
