<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Return Items - School Uniform Shop</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color:  #fff;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        
        }

        .container {
            background-color: #fff;
            padding: 40px; /* Add padding to all sides */
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            width: calc(100% - 40px); /* Full width minus padding */
            min-height: calc(100vh - 40px); /* Full height minus padding */
            box-sizing: border-box;
        }

        h1 {
            text-align: center;
            color: #333;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            margin-bottom: 5px;
            color: #333;
        }

        input, select, textarea {
            margin-bottom: 15px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        textarea {
            resize: vertical;
        }

        button {
            padding: 10px;
            background-color: blueviolet;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }

        button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

    <div class="container">
        <h1>Return Items</h1>
        <form action="index(1).html" method="POST">
            <label for="order-number">Order Number</label>
            <input type="text" id="order-number" name="order_number" placeholder="Enter your order number" required>

            <label for="email">Email Address</label>
            <input type="email" id="email" name="email" placeholder="Enter your email address" required>

            <label for="item-name">Item Name</label>
            <input type="text" id="item-name" name="item_name" placeholder="Enter the item name" required>

            <label for="reason">Reason for Return</label>
            <select id="reason" name="reason" required>
                <option value="">Select a reason</option>
                <option value="wrong_size">Wrong size</option>
                <option value="wrong_item">Received the wrong item</option>
                <option value="damaged">Item is damaged</option>
                <option value="other">Other</option>
            </select>

            <label for="comments">Additional Comments</label>
            <textarea id="comments" name="comments" rows="4" placeholder="Any additional information..."></textarea>

            <button type="submit" class="btn">Submit Return Request</button>
        </form>
    </div>

</body>
</html>
