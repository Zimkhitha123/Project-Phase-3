
<?php
header('Content-Type: application/json');

$serverName = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "khanya";

// Create connection
$conn = mysqli_connect($serverName, $dbUsername, $dbPassword, $dbName);

// Check connection
if (!$conn) {
    die(json_encode(['message' => 'Connection failed: ' . mysqli_connect_error()]));
}

// Get the POST data
$input = file_get_contents("php://input");
$data = json_decode($input, true);

if (!isset($data['cart']) || empty($data['cart'])) {
    echo json_encode(['message' => 'Cart is empty']);
    $conn->close();
    exit();
}

$cart = $data['cart'];

// Assuming CUSTOMER_ID is 1 for example
$customerId = 1; // This should be dynamically set based on the logged-in user
$totalCost = array_reduce($cart, function($total, $item) {
    return $total + ($item['price'] * $item['quantity']);
}, 0);

// Insert order
$orderQuery = $conn->prepare("INSERT INTO ORDERS (CUST_ID, ORDER_DATE, TOTAL_COST) VALUES (?, ?, ?)");
$orderDate = date('Y-m-d H:i:s');
$orderQuery->bind_param("isd", $customerId, $orderDate, $totalCost);

if ($orderQuery->execute()) {
    $orderId = $orderQuery->insert_id;

    // Insert order items
    $orderItemsQuery = $conn->prepare("INSERT INTO ORDER_ITEMS (ORDER_ID, PROD_ID, QUANTITY, ITEM_COST) VALUES (?, ?, ?, ?)");
    foreach ($cart as $item) {
        $orderItemsQuery->bind_param("iiid", $orderId, $item['prodId'], $item['quantity'], $item['price']);
        $orderItemsQuery->execute();
    }

    echo json_encode(['message' => 'Checkout successful', 'orderId' => $orderId]);
} else {
    echo json_encode(['message' => 'Error during checkout']);
}

$orderQuery->close();
$orderItemsQuery->close();
$conn->close();
?>
