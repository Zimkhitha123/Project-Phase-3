<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Customized uniforms for matric students</title>
    <link rel="stylesheet" href="uniforms.css" />
    <style>
    body{
            background-image: url("assets\\img\\blingbling.jpg");
    }
        </style>
  </head>
  <body>
    <h1>Customized uniforms for matric students</h1>

    <div class="info-section">
      <h2>Select School:</h2>
      <select id="school">
        <option value="Masibambane High School">Masibambane High School</option>
        <option value="Wallacedene High School">Wallacedene High School</option>
        <option value="Hector Peterson">Hector Peterson</option>
        <option value="Nqalweni JSS">Nqalweni JSS</option>
      </select>
    </div>
    <div class="info-section">
      <h2>Select Size:</h2>
      <select id="size">
        <option value="Small">Small</option>
        <option value="Medium">Medium</option>
        <option value="Large">Large</option>
        <option value="Extra large">Extra large</option>
      </select>
    </div>

    <div class="info-section">
      <h2>Select matric items:</h2>
      <select id="items">
        <option value="Matric jacket">Matric jacket</option>
        <option value="Matric jersey">Matric jersey</option>
        <option value="Matric ties">Matric ties</option>
      </select>
    </div>

    <div class="info-section">
      <h2>Samples:</h2>
      <div class="uniform-samples">
        <div class="uniform-item">
          <img
            src="assets\img\Matric.jpg"
            alt="Matric jacket"
          />
          <p class="price">Matric jackets from: R750.00</p>
        </div>
        <div class="uniform-item">
          <img
            src="assets\img\matric-jercey.jpg"
            alt="Matric jersey"
          />
          <p class="price">Matric jersey from: R450.00</p>
        </div>
        <div class="uniform-item">
          <img
            src="assets\img\matric-tie.jpg"
            alt=" Matric tie"
          />
          <p class="price">Matric ties from: R150.00</p>
        </div>
      </div>
    </div>

    <div class="info-section">
      <a href="Contact.html"
        >Contact us to give a full description of the desired design.
      </a>
    </div>

    <div class="info-section">
      <button onclick="addToCart()">Add to Cart</button>
    </div>

    <div>
      <a href="uniform.php">Back</a>
    </div>
    <div id="cart">
      <a href="latest_cart.php">Go to Cart</a>
    </div>

    <script>
      function addToCart() {
        const school = document.getElementById("school").value;
        const size = document.getElementById("size").value;
        const items = document.getElementById("items").value;

        const cartItem = { school, size, items };

        let cart = JSON.parse(localStorage.getItem("cart")) || [];
        cart.push(cartItem);
        localStorage.setItem("cart", JSON.stringify(cart));

        alert("Item added to cart: " + school + ", " + size + ", " + items);
      }
    </script>
  </body>
</html>
